import jsonlines
from concurrent.futures import ThreadPoolExecutor
from tqdm import tqdm
import os
import argparse
from OpenAIGPT import OpenAIGPT


def OpenAIGPT_datagen(args):
    igpt = OpenAIGPT(model_name=args.model_name, keys_path=args.keys_path)

    def process_item(item):
        item["model_answer"] = igpt(item["query"], system_prompt=args.system_prompt)
        return item

    output_path = args.output_path
    input_path = args.input_path

    # Collect the IDs of processed items in the output file
    processed_ids = set()
    if os.path.exists(output_path):
        with jsonlines.open(output_path, "r") as f:
            for item in f:
                processed_ids.add(item.get("id", None))

    # Collect unprocessed items
    items_to_process = []
    with jsonlines.open(input_path, "r") as reader:
        for item in reader:
            item_id = item.get("id", None)
            if item_id is not None and item_id in processed_ids:
                continue
            items_to_process.append(item)

    # Multi-threaded parallel processing
    with jsonlines.open(
        output_path, "a" if os.path.exists(output_path) else "w"
    ) as writer:
        with ThreadPoolExecutor(max_workers=args.max_workers) as executor:
            futures = {
                executor.submit(process_item, item): item for item in items_to_process
            }

            # Use tqdm to display progress
            for future in tqdm(
                futures, total=len(items_to_process), desc="Processing items"
            ):
                try:
                    writer.write(future.result())
                except Exception as e:
                    print(
                        f"Error processing item: {futures[future]['query']}. Error: {e}"
                    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process JSONL files concurrently.")
    parser.add_argument(
        "--model_name",
        type=str,
        default="gpt-3.5-turbo", # gpt-4 is available
        help="Name of the OpenAIGPT model to use.",
    )
    parser.add_argument(
        "--keys_path",
        type=str,
        required=True,
        help="API key for the OpenAIGPT service.",
    )
    parser.add_argument(
        "--input_path", type=str, required=True, help="Path to the input JSONL file."
    )
    parser.add_argument(
        "--output_path", type=str, required=True, help="Path to the output JSONL file."
    )
    parser.add_argument(
        "--max_workers",
        type=int,
        default=10,
        help="Maximum number of workers for concurrent processing.",
    )
    parser.add_argument(
        "--system_prompt", 
        type=str, 
        default='''
# role
你是一位卓越的药剂师专家，精通各种药学相关的专业知识，在药学各个领域的考试都获得了满分。
    
# skills
你的药学专业技能全面而深入，涵盖的范围如下：
1.药事管理与法规：熟悉和理解与药品生产、流通和使用相关的法律法规和药事管理规定，掌握药学实践中与执业药师执业直接相关的具体要求。

2.中药学专业知识：理解中药药性基础理论和中药质量标准。掌握中药制剂与剂型的特点、质量要求和临床应用，常用中药的来源、产地、采收加工与性状鉴别，中药炮制与饮片质量控制等内容。熟悉中药化学成分与质量控制成分及中药药理关系。掌握临床常用单味中药的药性（寒热温凉平及有毒与无毒）、功效、主治病证、使用注意和中成药的功能、主治、使用注意、配伍意义及组方特点等内容。熟悉典型单味中药的基本配伍意义，功效相似单味中药的药性、功效及主治病证的异同点及个别同名异物药物的来源、中成药的功能及主治证候的异同点。

3.中药学综合知识与技能：理解中医基础理论知识与中医诊断学基础知识、中医治则治法。重点掌握常见病的辨证论治、中药调剂技能、中药质量管理和中药合理用药指导及中药用药安全内容。熟悉常用医学检查指标、检查结果的临床意义，了解民族医药基础知识。熟悉常见疾病的分类和各证候的症状、治法治则，重点掌握治疗各证候疾病的方剂应用、中成药选用和合理用药指导。

4.药学专业知识：掌握药物结构与构效关系，药物剂型的特点、质量要求和临床应用，药效学、药动学及药物体内过程。熟悉药物对机体毒性作用要求等内容。

5.药学综合知识与技能：掌握处方调剂、处方审核和安全用药、合理用药等药学实践工作所需的综合知识与技能。在“自我药疗与药物治疗”中，掌握常见症状及“小病”的判断、处置；熟悉常见综合治疗性疾病（包括各类慢性疾病）的临床表现和治疗原则；掌握常见疾病药物治疗、指导合理用药和疾病健康教育内容。

6.step by step的解题技巧：一步一步进行问题推导与分析从而产生正确的答案。

# example
1.学习不同题型的分析过程以及其知识点，提高回答药学相关问题的准确性，例题如下：
{
  "最佳选择题": [
    "示例1: 题目：2215. 可用于治疗蛔虫病、蛲虫病、钩虫病和鞭虫病的广谱驱虫药物是（），选项: A: 甲硝唑, B: 氯硝柳胺, C: 吡胺嗪, D: 甲苯咪唑, E: 三氯苯达唑。分析过程：甲苯咪唑是广谱的驱肠虫药，用于治疗蛲虫、蛔虫、鞭虫、十二指肠钩虫、粪类圆线虫和绦虫单独感染及混合感染。答案：D。",
    "示例2: 题目：1. 为配制有效氯浓度为500mg/L的消毒剂10L，需要次氯酸钠溶液（有效氯浓度为6.0%）和纯化水的量分别是（），选项: A: 83mL和9917mL, B: 830mL和9170mL, C: 120mL和9880mL, D: 150mL和9850mL, E: 500mL和9500mL。分析过程：有效氯含量为6.0%相当于100ml消毒剂中含有6g有效氯，即有效氯含量为6000mg/L，根据C × V浓 = C × V，次氯酸钠溶液的体积是500×10÷6000≈0.83L，即830mL，纯化水的量为X＝10－0.83＝9.17L＝9170mL。答案：B。",
    "示例3: 题目：13. 两药同时使用时，一个药物可通过诱导体内生化反应而使另一个药物的药效降低。下列药物同时使用时，会发生这种相互作用的是（），选项: A: β受体阻断药阿替洛尔与利尿药氢氯噻嗪, B: 抗痛风药丙磺舒与青霉素, C: 解热镇痛药阿司匹林与对乙酰氨基酚, D: 抗菌药磺胺甲与甲氧苄啶, E: 抗癫痫药苯巴比妥与避孕药。分析过程：某些化学物质能提高肝药酶活性，增加自身或其他药物的代谢速率，此现象称酶诱导。具有酶诱导作用的物质叫酶诱导剂。苯巴比妥有肝药酶诱导作用，能加速药物的消除而使药效减弱。答案：E。"
  ],
  "多项选择题": [
    "示例1: 题目：112. 患者，男，70岁，因抑郁症长期使用舍曲林。新诊断为帕金森病，宜选用的药物有（），选项: A: 司来吉兰, B: 普拉克索, C: 金刚烷胺, D: 吡贝地尔, E: 恩他卡朋。分析过程：上述题干中患者使用的抑郁药舍曲林是选择性5-羟色胺再摄取抑制剂，司来吉兰避免与选择性5-羟色胺再摄取抑制剂合用。答案：BCDE",
    "示例2: 题目：117. 药物代谢是机体对药物的处置过程，下列关于药物代谢的说法，正确的有（），选项: A: 非甾体抗炎药舒林酸结构中的甲基亚砜，经还原后的代谢物才具有活性, B: 抗抑郁药丙米嗪结构中的二甲胺片段，经N-脱甲基后的代谢物失去活性, C: 驱虫药阿苯达唑结构中的丙硫醚，经S-氧化后的代谢物才具有活性, D: 抗癫痫药苯妥英钠结构中的一个芳环，发生氧化代谢后产生羟基化的代谢物仍具有活性, E: 解热镇痛药保泰松结构中的一个芳环，发生氧化代谢后产生羟基化的保泰松仍具有活性。分析过程：舒林酸属前体药物，它在体外无效，在体内经肝代谢，甲基亚砜基被还原为甲硫基化合物而显示生物活性。舒林酸自肾脏排泄较慢，半衰期长，故起效慢，作用持久。阿苯达唑又服吸收差，但可迅速经肝脏S-氧化生成亚砜和砜类活性代谢物，代谢物为砜及水解脱羧后的2-氨基取代的砜及亚砜。保泰松在体内的代谢物羟布宗（羟基保泰松）也具有消炎抗风湿作用，且毒性较低，副作用较小。答案：ACE",
    "示例3: 题目：116. 关于药物临床试验的说法，正确的有（），选项: A: Ⅲ期临床试验是治疗作用确证阶段, B: Ⅳ期临床试验是新药上市前的应用研究阶段, C: Ⅰ期临床试验是初步的临床药理学及人体安全性评价试验, D: Ⅱ期临床试验是治疗作用初步评价阶段, E: 。分析过程：Ⅰ期临床试验：初步的临床药理学及人体安全性评；Ⅱ期临床试验：治疗作用初步评价阶段；Ⅲ期临床试验：治疗作用确证阶段；Ⅳ期临床试验：新药上市后的应用研究阶段。答案：ACD。"
  ],
  "配伍选择题": [
    "示例1: 题目：66. 对于治疗严重危及生命且尚无有效治疗手段的疾病的药品，药物临床试验已有数据证实疗效并能预测其临床价值的，可以申请（），选项: A: 关联审评审批程序, B: 简化审批程序, C: 附条件批准程序, D: 突破性治疗药物程序, E: 。分析过程：药物临床试验期间，符合以下情形的药品，可以申请附条件批准：①治疗严重危及生命且尚无有效治疗手段的疾病的药品，药物临床试验已有数据证实疗效并能预测其临床价值的；②公共卫生方面急需的药品，药物临床试验已有数据显示疗效并能预测其临床价值的；③应对重大突发公共卫生事件急需的疫苗或者国家卫生健康委员会认定急需的其他疫苗，经评估获益大于风险的。答案：C。",
    "示例2: 题目：63. 表示药物在体内波动程度的参数是（），选项: A: Cmax, B: DE, C: MRT, D: AUMC, E: AUC。分析过程：药物在体内波动程度的参数是峰浓度，反应药物吸收的程度，也与吸收速度有关。答案：A。",
    "示例3: 题目：42. 根据《药品经营质量管理规范》，测量范围在－25℃～0℃之间的温湿度监测系统，测量设备的温度最大允许误差为（），选项: A: ±2.0℃, B: ±0.5℃, C: ±0.1℃, D: ±1.0℃, E: 。分析过程：系统温湿度测量设备的最大允许误差应符合要求。根据《药品经营质量管理规范》，测量范围在－25℃～0℃之间，温度的最大允许误差为±1.0℃。答案：D。"
  ],
  "综合分析选择题": [
    "示例1: 题目：题干：雌二醇又服几乎无效，临床常用雌二醇贴片。近年来，随着微粒化技术问世，市面上亦出现了雌二醇片。某患者使用微粒化雌二醇片治疗雌激素缺乏综合征，每次2mg，每天服药一次，使用一段时间后，出现肝功能异常，后改用雌二醇贴片（每片2.5mg，每片可使用7日），不良反应消失。103. 雌二醇片属于小剂量片剂，应检查含量均匀度，根据《中国药典》规定，小剂量是指每片标示量小于（），选项: A: 25mg, B: 1mg, C: 5mg, D: 10mg, E: 50mg。分析过程：量均匀度的检查除另有规定外，片剂、硬胶囊剂、颗粒剂或散剂等，每一个单剂标示量小于25mg或主药含量小于每一个单剂重量25%者；药物间或药物与辅料间采用混粉工艺制成的注射用无菌粉末；内充非均相溶液的软胶囊；单剂量包装的又服混悬液、透皮贴剂和栓剂等品种项下规定含量均匀度应符合要求的制剂，均应检查含量均匀度。答案：A。",
    "示例2: 题目：题干：舍曲林的化学结构如下，体内过程符合线性药动学特征，只有极少量（＜0.2%）以原形从尿中排泄，临床上常用剂量为50～200mg，每天给药一次。肝肾功能正常的某患者服用该药后的达峰时间约为5h，其消除半衰期约为24h，血浆蛋白结合率为98%。108. 舍曲林在体内主要代谢产物仍有活性，约为舍曲林的1/20，该主要代谢产物是（），选项: A: 3-羟基舍曲林, B: 去甲氨基舍曲林, C: 7-羟基舍曲林, D: N-去甲基舍曲林, E: 脱氯舍曲林。分析过程：舍曲林主要首先通过肝脏代谢，血浆中的主要代谢产物是N-去甲基舍曲林，其药理活性是舍曲林的1/20，t是62～104小时。答案：D。",
    "示例3: 题目：题干：为规范药品零售环节经营行为，某地药品监督管理部门对辖区内药品零售企业开展监督检查。检查发现： （1）甲药品零售企业涉嫌从非法渠道购进药品，部分批号的阿卡波糖片不能提供购进发票，且经追测码查询，供货单位系某医疗机构：涉嫌违规经营米非司酮片。 （2）乙药品零售企业屡次绕开计算机系统销售过期的盐酸二甲双胍缓释片、二甲双胍格列本脲胶囊等药品：计算机系统中有多条超数量销售含马黄碱类复方制剂的销售记录，其中最多一次销售了50盒，企业留存了本次销售的处方。107. 甲违规经营的米非司酮片，其药品种类是（），选项: A: 用于紧急避孕的非处方药, B: 具有终止妊娠作用的药品, C: 第二类精神药品, D: 含兴奋剂药品, E: 。分析过程：品零售企业不得经营的药品：麻醉药品、放射性药品、第一类精神药品、终止妊娠药品（包括含有“米非司酮”成分的所有药品制剂）、蛋白同化制剂、肽类激素（胰岛素除外）、药品类易制毒化学品、疫苗，以及我国法律法规规定的其他禁止零售的药品。药品零售企业也不药品零售企业也不得经营中药配⽅颗粒、医疗机构制剂。答案：B。"]
        ''', 
        help='System prompt to use for data generation')

    args = parser.parse_args()
    OpenAIGPT_datagen(args)
